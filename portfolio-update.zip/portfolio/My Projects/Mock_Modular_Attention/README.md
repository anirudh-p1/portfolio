<h1>Mock Modular Attention</h1>

<div class="project-detail-wrap">
  <div class="project-detail-text">
    <!-- CHANGE ME: expand this into a fuller description -- the problem, your approach, results. -->
    <p>Uses Ramanujan Q-series and mock theta kernels for symmetry-constrained sequential learning.</p>
    <div class="project-links">
      <a href="https://github.com/anirudh-p1/Mock_Modular_Attention" target="_blank">GitHub Repo</a>
      <!-- CHANGE ME: uncomment and add a link if you have a demo/explainer video -->
      <!-- <a href="https://youtube.com/..." target="_blank">Video Walkthrough</a> -->
    </div>
  </div>
  <div class="project-detail-images">
    <!-- CHANGE ME: replace with a real screenshot/diagram, or delete this whole img tag if you do not have one yet -->
    <img src="https://via.placeholder.com/400x250?text=Mock+Modular+Attention" alt="Mock Modular Attention screenshot">
  </div>
</div>
