<h1>All Projects</h1>

<div class="projects-grid" id="all-projects-grid"></div>
