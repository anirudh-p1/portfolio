<h1>My Projects</h1>

<p>Click the arrows to browse, or click a card to open that project.</p>

<div id="project-carousel"></div>
