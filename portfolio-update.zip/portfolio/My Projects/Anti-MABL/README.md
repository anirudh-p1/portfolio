<h1>Anti-MABL</h1>

<div class="project-detail-wrap">
  <div class="project-detail-text">
    <!-- CHANGE ME: expand this into a fuller description -- the problem, your approach, results. -->
    <p>ML-powered resistance control system for microgravity (space) upper-body training machines, addressing microgravity-associated bone loss.</p>
    <div class="project-links">
      <a href="https://github.com/anirudh-p1/Anti-MABL" target="_blank">GitHub Repo</a>
      <!-- CHANGE ME: uncomment and add a link if you have a demo/explainer video -->
      <!-- <a href="https://youtube.com/..." target="_blank">Video Walkthrough</a> -->
    </div>
  </div>
  <div class="project-detail-images">
    <!-- CHANGE ME: replace with a real screenshot/diagram, or delete this whole img tag if you do not have one yet -->
    <img src="https://via.placeholder.com/400x250?text=Anti-MABL" alt="Anti-MABL screenshot">
  </div>
</div>
