<h1>FreshSight-AI</h1>

<div class="project-detail-wrap">
  <div class="project-detail-text">
    <!-- CHANGE ME: expand this into a fuller description -- the problem, your approach, results. -->
    <p>A CNN monitoring perishable produce freshness in real time at the retail stage of the food supply chain.</p>
    <div class="project-links">
      <a href="https://github.com/anirudh-p1/FreshSight-AI" target="_blank">GitHub Repo</a>
      <!-- CHANGE ME: uncomment and add a link if you have a demo/explainer video -->
      <!-- <a href="https://youtube.com/..." target="_blank">Video Walkthrough</a> -->
    </div>
  </div>
  <div class="project-detail-images">
    <!-- CHANGE ME: replace with a real screenshot/diagram, or delete this whole img tag if you do not have one yet -->
    <img src="https://via.placeholder.com/400x250?text=FreshSight-AI" alt="FreshSight-AI screenshot">
  </div>
</div>
