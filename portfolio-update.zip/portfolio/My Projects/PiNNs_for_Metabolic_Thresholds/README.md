<h1>PiNNs for Metabolic Thresholds</h1>

<div class="project-detail-wrap">
  <div class="project-detail-text">
    <!-- CHANGE ME: expand this into a fuller description -- the problem, your approach, results. -->
    <p>Physics-informed neural networks to predict metabolic thresholds.</p>
    <div class="project-links">
      <a href="https://github.com/anirudh-p1/PiNNs_for_Metabolic_Thresholds" target="_blank">GitHub Repo</a>
      <!-- CHANGE ME: uncomment and add a link if you have a demo/explainer video -->
      <!-- <a href="https://youtube.com/..." target="_blank">Video Walkthrough</a> -->
    </div>
  </div>
  <div class="project-detail-images">
    <!-- CHANGE ME: replace with a real screenshot/diagram, or delete this whole img tag if you do not have one yet -->
    <img src="https://via.placeholder.com/400x250?text=PiNNs+for+Metabolic+Thresholds" alt="PiNNs for Metabolic Thresholds screenshot">
  </div>
</div>
