<h1>Non-Trivial Fellowship Project</h1>

<div class="project-detail-wrap">
  <div class="project-detail-text">
    <!-- CHANGE ME: expand this into a fuller description -- the problem, your approach, results. -->
    <p>9-week research fellowship project on transformer interpretability, comparing softmax attention against bounded-sigmoid and squared-ReLU kernels as an architectural fix for superposition/polysemanticity.</p>
    <div class="project-links">
      <a href="https://github.com/anirudh-p1/Non-Trivial-Project" target="_blank">GitHub Repo</a>
      <!-- CHANGE ME: uncomment and add a link if you have a demo/explainer video -->
      <!-- <a href="https://youtube.com/..." target="_blank">Video Walkthrough</a> -->
    </div>
  </div>
  <div class="project-detail-images">
    <!-- CHANGE ME: replace with a real screenshot/diagram, or delete this whole img tag if you do not have one yet -->
    <img src="https://via.placeholder.com/400x250?text=Non-Trivial+Fellowship+Project" alt="Non-Trivial Fellowship Project screenshot">
  </div>
</div>
