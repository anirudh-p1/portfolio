<div class="program-header">
  <h1>COMPOS</h1>
  <!-- CHANGE ME: set href to COMPOS's real website, and img src to their real logo URL -->
  <a class="program-logo-link" href="https://example.com" target="_blank">
    <img src="https://via.placeholder.com/100x100?text=Logo" alt="COMPOS logo">
  </a>
</div>

<!-- CHANGE ME: write a bit about your work / involvement in COMPOS here. -->
<p>Write a short description of what COMPOS is and what you did there.</p>
