<div class="program-header">
  <h1>Non-Trivial Fellowship</h1>
  <!-- CHANGE ME: set href to the Non-Trivial Fellowship's real website, and img src to their real logo URL -->
  <a class="program-logo-link" href="https://example.com" target="_blank">
    <img src="https://via.placeholder.com/100x100?text=Logo" alt="Non-Trivial Fellowship logo">
  </a>
</div>

<!-- CHANGE ME: write a bit about your work in the Non-Trivial Fellowship here. -->
<p>A 9-week research fellowship. I worked on transformer interpretability, exploring alternative
attention kernels (bounded-sigmoid, squared-ReLU) as an architectural fix for superposition,
comparing them against softmax attention on synthetic data.</p>

<div class="link-card-row">
  <a href="#/My%20Projects/Non-Trivial-Project/README" class="link-card">See the project write-up →</a>
</div>
